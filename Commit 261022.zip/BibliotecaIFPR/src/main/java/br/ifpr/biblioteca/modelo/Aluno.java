/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ifpr.biblioteca.modelo;

import java.util.Calendar;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 *
 * @author Aluno
 */
@Entity
@Table(name="tb_aluno")
public class Aluno {

    @Id
    @Column(name = "id_alunop", unique = true, nullable = false)
    private Integer pessoaID;
    
    @Column(name="ra_aluno")
    private String RA;
    
    @Column(name="senha_aluno")
    private String senha;
    
    public Aluno() {}
    
    public Aluno(int pessoaID, String senha){
        this.pessoaID = pessoaID;
        this.RA = geraRaAluno();
        this.senha = senha;
    }
    
    public Aluno(String alunoRA, int pessoaID){
        this.pessoaID = pessoaID;
        this.RA = alunoRA;
        
    }
    
    
    public String getRA() {
        return RA;
    }

    public void setRA(String RA) {
        this.RA = RA;
    }
    
    public static String geraRaAluno() {
        
        
        Random gerador = new Random();
        Calendar cal = GregorianCalendar.getInstance();     
        
        String ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        int num;

        while(true) { // Gerador de numero aleatorio positivo
            num = gerador.nextInt();
            if(num > 0 && num < 999999) {
                break;
            }
        }
        
        String alunoRa  = ano + Integer.toString(num);
        
        return alunoRa;
        
        
    }
    
    /**
     * @return the pessoaID
     */
    public Integer getPessoaID() {
        return pessoaID;
    }

    /**
     * @param pessoaID the pessoaID to set
     */
    public void setPessoaID(Integer pessoaID) {
        this.pessoaID = pessoaID;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

}
