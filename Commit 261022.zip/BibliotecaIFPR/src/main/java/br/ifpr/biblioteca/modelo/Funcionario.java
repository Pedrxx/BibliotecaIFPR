/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ifpr.biblioteca.modelo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 *
 * @author pedro
 */
@Entity
@Table(name="tb_funcionario")
public class Funcionario extends Pessoa{
    
    @Column(name="ciap_funcionario", unique=true, nullable=false)
    private String CIAP;
    @Column(name="senha_funcionario")
    private String senha;
    
    public Funcionario() {}
    
    public Funcionario(String CIAP, String senha, String nome, String CPF, String email, String telefone, boolean ativo) {   
        super(nome,CPF,email,telefone,ativo);
        this.CIAP = CIAP;
        this.senha = senha;
    
    }
    
}
